﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LearnInfrastructure.DTO
{
    public class StringResponseMessage
    {
        public string ErrorMsgIsNull = "{0} is null";
        public string ErrorMsgDataNotFound = "{0} is not found";
        public string ErrorMsgMandatoryFieldMustBeFilled = "Mandatory Fields must be filled";
        public string ErrorMsgIsNotvalid = "The {0} format is not valid";
        public string SuccessCreateMsg = "{0} have been successfully created";
        public string SuccessUpdateMsg = "{0} have been successfully updated";
        public string SuccessDeleteMsg = "{0} have been successfully deleted";
        public string SuccessMsg = "Success";
        public string ErrorMsg = "Unexpected error has occured";
    }
}
