﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LearnInfrastructure.DTO
{
    public class ListResponse<T> : BaseResponse
    {
        public IEnumerable<T> Data { get; set; }
    }
}
