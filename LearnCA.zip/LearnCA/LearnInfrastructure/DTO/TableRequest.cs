﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace LearnInfrastructure.DTO
{
    public abstract class TableRequest
    {
        public TableRequest()
        {
            SortOrder = new Dictionary<string, bool?>();
            SearchCriteria = new Dictionary<string, string>();
        }
        // Number data shown
        public int NumberOfRecord { get; set; }
        public int Page { get; set; }
        public Dictionary<string, bool?> SortOrder { get; set; }
        public Dictionary<string, string> SearchCriteria { get; set; }
    }
}
