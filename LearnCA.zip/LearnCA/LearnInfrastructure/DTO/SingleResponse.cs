﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LearnInfrastructure.DTO
{
    public class SingleResponse<T> : BaseResponse
    {
        public T Data { get; set; }
    }
}
