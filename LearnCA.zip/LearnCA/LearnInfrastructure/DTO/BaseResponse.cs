﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LearnInfrastructure.DTO
{
    public class BaseResponse
    {
        public bool IsError { get; set; }
        public string Message { get; set; }
    }
}
