﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LearnInfrastructure.DTO
{
    public class TableResponse<T> : BaseResponse
    {
        public IEnumerable<T> Data { get; set; }
        public int TotalData { get; set; }
        //Number data shown
        public int NumberOfRecord { get; set; }
        public int Page { get; set; }
    }
}
