﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Options;

namespace LearnRepository.Models
{
    public partial class RewardDBContext : DbContext
    {
       public RewardDBContext(DbContextOptions<RewardDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Admin> Admin { get; set; }
        public virtual DbSet<Customer> Customer { get; set; }
        public virtual DbSet<History> History { get; set; }
        public virtual DbSet<Merchant> Merchant { get; set; }
        public virtual DbSet<Reward> Reward { get; set; }
        public virtual DbSet<Voucher> Voucher { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                //optionsBuilder.UseSqlServer("Server=localhost;Database=RewardDB;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>(entity =>
            {
                entity.Property(e => e.AdminId)
                    .HasColumnName("AdminID")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasKey(e => e.CustId)
                    .HasName("pk_Customer");

                entity.Property(e => e.CustId)
                    .HasColumnName("custID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnName("email")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasColumnName("phone")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<History>(entity =>
            {
                entity.HasKey(e => e.HId)
                    .HasName("pk_History");

                entity.Property(e => e.HId)
                    .HasColumnName("hID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CustId).HasColumnName("custID");

                entity.Property(e => e.Datetime)
                    .HasColumnName("datetime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnName("description")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HName)
                    .IsRequired()
                    .HasColumnName("hName")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Price)
                    .HasColumnName("price")
                    .HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Cust)
                    .WithMany(p => p.History)
                    .HasForeignKey(d => d.CustId)
                    .HasConstraintName("fk_customer");
            });

            modelBuilder.Entity<Merchant>(entity =>
            {
                entity.HasKey(e => e.MId)
                    .HasName("pk_Merchant");

                entity.Property(e => e.MId)
                    .HasColumnName("mID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnName("email")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Loc)
                    .IsRequired()
                    .HasColumnName("loc")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Owner)
                    .IsRequired()
                    .HasColumnName("owner")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasColumnName("phone")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasColumnName("username")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Reward>(entity =>
            {
                entity.HasKey(e => e.RId)
                    .HasName("pk_Reward");

                entity.Property(e => e.RId)
                    .HasColumnName("rID")
                    .ValueGeneratedNever();

                entity.Property(e => e.HId).HasColumnName("hID");

                entity.Property(e => e.Pts)
                    .HasColumnName("pts")
                    .HasColumnType("decimal(6, 2)");

                entity.HasOne(d => d.H)
                    .WithMany(p => p.Reward)
                    .HasForeignKey(d => d.HId)
                    .HasConstraintName("fk_history");
            });

            modelBuilder.Entity<Voucher>(entity =>
            {
                entity.HasKey(e => e.VId)
                    .HasName("pk_Voucher");

                entity.Property(e => e.VId)
                    .HasColumnName("vID")
                    .ValueGeneratedNever();

                entity.Property(e => e.MId).HasColumnName("mID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.TotalPrice)
                    .HasColumnName("totalPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPts)
                    .HasColumnName("totalPts")
                    .HasColumnType("decimal(6, 2)");

                entity.HasOne(d => d.M)
                    .WithMany(p => p.Voucher)
                    .HasForeignKey(d => d.MId)
                    .HasConstraintName("fk_merchant");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
