﻿using System;
using System.Collections.Generic;

namespace LearnRepository.Models
{
    public partial class Reward
    {
        public int RId { get; set; }
        public decimal Pts { get; set; }
        public int? HId { get; set; }

        public virtual History H { get; set; }
    }
}
