﻿using System;
using System.Collections.Generic;

namespace LearnRepository.Models
{
    public partial class Merchant
    {
        public Merchant()
        {
            Voucher = new HashSet<Voucher>();
        }

        public int MId { get; set; }
        public string Name { get; set; }
        public string Owner { get; set; }
        public string Loc { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public virtual ICollection<Voucher> Voucher { get; set; }
    }
}
