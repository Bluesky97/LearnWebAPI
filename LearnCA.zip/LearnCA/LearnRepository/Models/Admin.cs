﻿using System;
using System.Collections.Generic;

namespace LearnRepository.Models
{
    public partial class Admin
    {
        public string AdminId { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
