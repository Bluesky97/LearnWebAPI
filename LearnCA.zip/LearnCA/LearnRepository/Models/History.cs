﻿using System;
using System.Collections.Generic;

namespace LearnRepository.Models
{
    public partial class History
    {
        public History()
        {
            Reward = new HashSet<Reward>();
        }

        public int HId { get; set; }
        public string HName { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
        public DateTime Datetime { get; set; }
        public int? CustId { get; set; }

        public virtual Customer Cust { get; set; }
        public virtual ICollection<Reward> Reward { get; set; }
    }
}
