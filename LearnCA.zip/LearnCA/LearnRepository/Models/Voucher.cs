﻿using System;
using System.Collections.Generic;

namespace LearnRepository.Models
{
    public partial class Voucher
    {
        public int VId { get; set; }
        public string Name { get; set; }
        public decimal TotalPts { get; set; }
        public decimal TotalPrice { get; set; }
        public int? MId { get; set; }

        public virtual Merchant M { get; set; }
    }
}
