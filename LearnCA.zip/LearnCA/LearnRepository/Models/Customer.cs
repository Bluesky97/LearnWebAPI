﻿using System;
using System.Collections.Generic;

namespace LearnRepository.Models
{
    public partial class Customer
    {
        public Customer()
        {
            History = new HashSet<History>();
        }

        public int CustId { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public virtual ICollection<History> History { get; set; }
    }
}
