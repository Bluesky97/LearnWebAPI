﻿using LearnRepository.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LearnRepository.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly RewardDBContext _db;
        private DbSet<T> table = null;
        public Repository(RewardDBContext _db)
        {
            this._db = _db;
            table = _db.Set<T>();
        }

        public void Delete(object id)
        {
            T existing = table.Find(id);
            table.Remove(existing);
            _db.SaveChanges();
        }

        public IEnumerable<T> GetAll()
        {
            return table.ToList();
        }

        public T GetByID(object id)
        {
            return table.Find(id);
        }

        public void Insert(T obj)
        {
            table.Add(obj);
        }

        public void Save()
        {
            _db.SaveChanges();
        }

        public void Update(T obj)
        {
            table.Attach(obj);
            _db.Entry(obj).State = EntityState.Modified;
        }
    }
}
