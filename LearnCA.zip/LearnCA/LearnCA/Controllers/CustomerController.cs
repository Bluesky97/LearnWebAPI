﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LearnRepository.Models;
using LearnRepository.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LearnCA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly IRepository<Customer> repo;

        public CustomerController(IRepository<Customer> repo)
        {
            this.repo = repo;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Customer>> GetCustomer()
        {
            var result = repo.GetAll();
            return Ok(result);
        }
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var result = repo.GetByID(id);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }
        [HttpPost]
        public IActionResult Post([FromBody]Customer entity)
        {
            if (ModelState.IsValid)
            {
                repo.Insert(entity);
                repo.Save();
            }
            return Ok(entity);
        }
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Customer customer)
        {
            if (id != customer.CustId)
            {
                return BadRequest();
            }
            try
            {
                if (ModelState.IsValid)
                {
                    repo.Update(customer);
                    repo.Save();
                }
                return Ok(customer);
            }
            catch (DbUpdateConcurrencyException)
            {
                return NotFound();
            }
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            repo.Delete(id);
            return Ok(id);
        }
    }
}