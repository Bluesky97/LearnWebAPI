using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using AutoMapper;
using LearnRepository.Models;
using Microsoft.EntityFrameworkCore;
using System.Web.Cors;
using LearnRepository.Repository;

namespace LearnCA
{
    public class Startup
    {
        private const string corsPolicy = "MyPolicy";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddCors(options =>
            {
                options.AddPolicy(corsPolicy,
                builder =>
                {
                    builder
                    .WithOrigins("http://localhost:44301", "http://localhost:44301")
                    .AllowAnyHeader().AllowAnyMethod().AllowCredentials();
                });
            });
            services.AddMvc();
            services.AddAutoMapper(typeof(Startup));
            services.AddEntityFrameworkSqlServer();
            services.AddDbContextPool<RewardDBContext>((serviceProvider, optionsBuilder) =>
            {
                optionsBuilder.UseInternalServiceProvider(serviceProvider);
                optionsBuilder.UseSqlServer(Configuration.GetConnectionString("myConnectionStrings"));
            });
            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
            //services.AddScoped(typeof(RewardDBContext), typeof(RewardDBContext));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseCors(corsPolicy);

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
