﻿using LearnInfrastructure.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace LearnServices
{
    public class BaseService<T> where T:class
    {
        protected StringResponseMessage ResponseMessage { get; } = new StringResponseMessage();
        protected void SetResponse (SingleResponse<T>response, bool IsError, string errMessage)
        {
            response.IsError = IsError;
            response.Message = errMessage;
        }
        protected void SetResponse(ListResponse<T> response, bool IsError, string errMessage)
        {
            response.IsError = IsError;
            response.Message = errMessage;
        }
        protected void SetResponse(TableResponse<T> response, bool IsError, string errMessage)
        {
            response.IsError = IsError;
            response.Message = errMessage;
        }
    }


}
